package com.vloggervoyages.graphql;

import com.vloggervoyages.entity.Tour;
import com.vloggervoyages.service.TourService;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class TourResolver {

    private final TourService tourService;

    public TourResolver(TourService tourService) {
        this.tourService = tourService;
    }

    @QueryMapping
    public List<Tour> tours() {
        return tourService.getAllTours();
    }

    @QueryMapping
    public Tour tour(@Argument String slug) {
        return tourService.getTourBySlug(slug);
    }
}