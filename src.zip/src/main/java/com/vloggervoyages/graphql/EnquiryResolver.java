package com.vloggervoyages.graphql;

import com.vloggervoyages.entity.Enquiry;
import com.vloggervoyages.service.EnquiryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.stereotype.Controller;
import org.springframework.graphql.data.method.annotation.Argument;

import java.util.List;

@Controller
public class EnquiryResolver {

    @Autowired
    private EnquiryService enquiryService;

    @QueryMapping
    public List<Enquiry> enquiries() {
        return enquiryService.getAllEnquiries();
    }

    @MutationMapping
    public Enquiry submitEnquiry(
            @Argument String name,
            @Argument String email,
            @Argument String phone,
            @Argument String message
    ) {
        return enquiryService.saveEnquiry(name, email, phone, message);
    }
}