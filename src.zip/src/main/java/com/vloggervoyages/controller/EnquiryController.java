package com.vloggervoyages.controller;

import com.vloggervoyages.entity.Enquiry;
import com.vloggervoyages.repository.EnquiryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/enquiries")
@RequiredArgsConstructor
@CrossOrigin
public class EnquiryController {

    private final EnquiryRepository enquiryRepository;

    @PostMapping
    public Enquiry submit(@RequestBody Enquiry enquiry) {
        enquiry.setCreatedAt(LocalDateTime.now());
        return enquiryRepository.save(enquiry);
    }
}
