package com.vloggervoyages.controller;

import com.vloggervoyages.entity.Tour;
import com.vloggervoyages.service.TourService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tours")
@RequiredArgsConstructor
@CrossOrigin
public class TourController {

    private final TourService tourService;

    @GetMapping
    public List<Tour> getTours() {
        return tourService.getPublishedTours();
    }

    @GetMapping("/{slug}")
    public Tour getTour(@PathVariable String slug) {
        return tourService.getBySlug(slug);
    }
}
