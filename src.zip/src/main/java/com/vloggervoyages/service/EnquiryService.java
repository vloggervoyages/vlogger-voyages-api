package com.vloggervoyages.service;

import com.vloggervoyages.entity.Enquiry;
import com.vloggervoyages.repository.EnquiryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class EnquiryService {

    @Autowired
    private EnquiryRepository enquiryRepository;

    public List<Enquiry> getAllEnquiries() {
        return enquiryRepository.findAll();
    }

    public Enquiry saveEnquiry(String name, String email, String phone, String message) {

        Enquiry enquiry = new Enquiry();

        enquiry.setName(name);
        enquiry.setEmail(email);
        enquiry.setPhone(phone);
        enquiry.setMessage(message);
        enquiry.setCreatedAt(LocalDateTime.now());

        return enquiryRepository.save(enquiry);
    }
}