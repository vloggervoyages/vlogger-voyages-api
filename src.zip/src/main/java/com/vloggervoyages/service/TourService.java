package com.vloggervoyages.service;

import com.vloggervoyages.entity.Tour;
import com.vloggervoyages.repository.TourRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TourService {

    private final TourRepository tourRepository;

    public TourService(TourRepository tourRepository) {
        this.tourRepository = tourRepository;
    }

    public List<Tour> getAllTours() {
        return tourRepository.findAll();
    }

    public Tour getTourBySlug(String slug) {
        return tourRepository.findBySlug(slug).orElse(null);
    }
}